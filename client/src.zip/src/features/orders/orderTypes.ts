export type PaymentMethod='COD'|'VNPAY'|'ZALOPAY'|'MOCK'
export interface Address{ id:number;label:string;recipientName:string;phone:string;province:string;district:string;ward:string;detailAddress:string;defaultAddress:boolean }
export interface OrderItem{id:number;productId:number;productName:string;thumbnailUrl?:string;unitPrice:number;quantity:number;subtotal:number}
export interface Order{id:number;orderCode:string;recipientName:string;recipientPhone:string;shippingAddress:string;note?:string;subtotal:number;shippingFee:number;totalAmount:number;status:string;paymentMethod:PaymentMethod;paymentStatus:string;createdAt:string;items:OrderItem[]}
export interface ApiResponse<T>{success:boolean;message:string;data:T}
