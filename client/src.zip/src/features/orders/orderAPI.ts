import {api} from '../../services/api'; import type {Address,ApiResponse,Order,PaymentMethod} from './orderTypes'
export const getAddresses=async()=> (await api.get<ApiResponse<Address[]>>('/addresses')).data.data
export const createAddress=async(body:Omit<Address,'id'>)=> (await api.post<ApiResponse<Address>>('/addresses',body)).data.data
export const createOrder=async(addressId:number,paymentMethod:PaymentMethod,note:string)=> (await api.post<ApiResponse<Order>>('/orders',{addressId,paymentMethod,note})).data.data
export const getMyOrders=async()=> (await api.get<ApiResponse<Order[]>>('/orders')).data.data
export const cancelOrder=async(id:number,reason:string)=> (await api.post<ApiResponse<Order>>(`/orders/${id}/cancel`,{reason})).data.data
export const createPaymentUrl=async(id:number)=> (await api.post<ApiResponse<{paymentUrl:string}>>(`/orders/${id}/payment-url`)).data.data
